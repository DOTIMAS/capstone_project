<?php
include "database.php";
session_start();

$pdo = Database::connect();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");

    try {
        if ($stmt->execute([$username, $hashed_password])) {
            echo "<script>alert('Account created successfully!'); window.location='login.php';</script>";
        } else {
            echo "<script>alert('Signup failed');</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('Signup failed: Username may already exist');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #fafafa;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        .topnav {
            list-style: none;
            margin: 30px auto;
            padding: 0;
            overflow: hidden;
            background: #b14134;
            width: 75%;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            text-align: center;
        }
        .topnav li { float: left; }
        .topnav li a {
            display: block;
            color: #fff;
            font-weight: 600;
            padding: 20px 26px;
            text-decoration: none;
            transition: 0.3s;
            font-size: 18px;
        }
        .topnav li a:hover:not(.active) { background: #d35b4d; }
        .active { background: #333; }

        @media (max-width: 768px) { .topnav li { float: none; } }

        h1 {
            text-align: center;
            margin-top: 40px;
            color: #b14134;
            font-family: "Engravers Old English", serif;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        }

        .form-container {
            width: 400px;
            margin: 70px auto;
            background: white;
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 4px 18px rgba(0,0,0,0.1);
        }

        .form-container h2 {
            text-align: center;
            color: #b14134;
            margin-bottom: 25px;
            font-weight: 700;
        }

        input {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            border: 1px solid #ccc;
            margin-bottom: 15px;
            font-size: 16px;
        }

        button {
            width: 100%;
            background: #b14134;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #d35b4d;
        }

        .link {
            text-align: center;
            margin-top: 15px;
        }

        .link a {
            color: #b14134;
            font-weight: bold;
            text-decoration: none;
        }

        .link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h1>SBCA Student RFID System</h1>

<ul class="topnav">
    <li><a href="home.php">Home</a></li>
    <li><a href="signup.php" class="active">Sign Up</a></li>
    <li style="float:right;"><a href="login.php">Login</a></li>
</ul>

<div class="form-container">
    <h2>Create Account</h2>

    <form method="POST">
        <input type="text" name="username" placeholder="Enter username" required>
        <input type="password" name="password" placeholder="Enter password" required>

        <button type="submit">Sign Up</button>

        <div class="link">
            Already have an account? <a href="login.php">Login</a>
        </div>
    </form>
</div>

</body>
</html>
