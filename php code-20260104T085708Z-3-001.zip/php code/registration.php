<?php
    $Write="<?php $" . "UIDresult=''; " . "echo $" . "UIDresult;" . " ?>";
    file_put_contents('UIDContainer.php',$Write);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
    <script src="jquery.min.js"></script>

    <script>
        $(document).ready(function(){
            $("#getUID").load("UIDContainer.php");
            setInterval(function() {
                $("#getUID").load("UIDContainer.php");
            }, 500);
        });
    </script>

    <title>Registration : SBCA RFID System</title>

    <style>
        /* Body background with logo */
        body {
            background: url('bernadettelogo.png') no-repeat left top;
            background-size: 400px;   /* adjust size */
            background-color: #fafafa;
            text-align:center;
        }

        h1 {
            font-family: "Engravers Old English", serif;
            margin-top: 35px;
            text-align: center;
            color: #b14134;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        }

        /* Navigation Bar */
        .topnav {
            list-style: none;
            margin: 30px auto;
            padding: 0;
            overflow: hidden;
            background: #b14134;
            width: 75%;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .topnav li { float: left; }

        .topnav li a {
            display: block;
            color: white;
            font-weight: 600;
            text-align: center;
            padding: 18px 26px;
            text-decoration: none;
            font-size: 18px;
            transition: 0.3s;
        }

        .topnav li a:hover:not(.active) {
            background: #d35b4d;
        }

        .active {
            background: #333333;
        }

        @media (max-width: 600px) {
            .topnav li { float: none; }
        }

        /* Center Registration Card */
        .reg-card {
            width: 95%;
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 30px 35px;
            border-radius: 18px;
            margin-top: 25px;
            box-shadow: 0 5px 18px rgba(0,0,0,0.12);
        }

        h3 {
            text-align: center;
            font-weight: 700;
            color: #444;
            margin-bottom: 20px;
        }

        label {
            font-weight: 600;
            margin-top: 8px;
            display: block;
            text-align: left;
            color: #444;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px 12px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background: #fafafa;
            font-size: 15px;
        }

        textarea {
            resize: none;
            height: 45px;
        }

        .btn-success {
            margin-top: 20px;
            width: 100%;
            padding: 12px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: bold;
        }
    </style>
</head>

<body>

    <h1>SBCA Student RFID System</h1>

    <ul class="topnav">
        <li><a href="home.php">Home</a></li>
        <li><a href="user_data.php">User Data</a></li>
        <li><a class="active" href="registration.php">Registration</a></li>
        <li><a href="read_tag.php">Read Tag ID</a></li>
    </ul>

    <div class="reg-card">

        <h3>Registration Form</h3>

        <form action="insertDB.php" method="post">

            <label>ID</label>
            <textarea name="id" id="getUID" placeholder="Tag your card to show ID" required></textarea>

            <label>Name</label>
            <input type="text" name="name" required>

            <label>Gender</label>
            <select name="gender" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>

            <label>Email Address</label>
            <input type="email" name="email" required>

            <label>Mobile Number</label>
            <input type="text" name="mobile" required>

            <button type="submit" class="btn btn-success">Save</button>
        </form>
    </div>

</body>
</html>
