<?php
    $Write="<?php $" . "UIDresult=''; " . "echo $" . "UIDresult;" . " ?>";
    file_put_contents('UIDContainer.php',$Write);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <title>Read Tag | SBCA RFID System</title>

    <style>
        /* Body background with logo */
        body {
            background: url('bernadettelogo.png') no-repeat left top;
            background-size: 400px;   /* adjust size */
            background-color: #fafafa;
            text-align:center;
        }

        h1 {
            font-family: "Engravers Old English", serif;
            text-align: center;
            color: #b14134;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
            margin-bottom: 20px;
        }

        h3 {
            text-align: center;
            font-weight: 600;
            color: #444;
            margin-bottom: 20px;
        }

        /* Navigation Bar */
        .topnav {
            list-style: none;
            margin: 20px auto;
            padding: 0;
            overflow: hidden;
            background: #b14134;
            width: 75%;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .topnav li { float: left; }

        .topnav li a {
            display: block;
            color: white;
            font-weight: 600;
            text-align: center;
            padding: 18px 26px;
            text-decoration: none;
            font-size: 18px;
            transition: 0.3s;
        }

        .topnav li a:hover:not(.active) {
            background: #d35b4d;
        }

        .active { background: #333333; }

        @media (max-width: 600px) {
            .topnav li { float: none; }
        }

        /* Card for UID and user data */
        .data-card {
            width: 95%;
            max-width: 550px;
            margin: auto;
            background: white;
            padding: 25px 30px;
            border-radius: 18px;
            margin-top: 25px;
            box-shadow: 0 5px 18px rgba(0,0,0,0.12);
        }

        #getUID {
            display: none;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 15px;
        }

        th {
            background: #b14134;
            color: #fff;
            padding: 12px;
            border-radius: 12px 12px 0 0;
        }

        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        tr:nth-child(even) { background: #f9f9f9; }

        .blink {
            color: #b14134;
            font-weight: 600;
        }
    </style>

    <script>
        $(document).ready(function(){
            $("#getUID").load("UIDContainer.php");
            setInterval(function() {
                $("#getUID").load("UIDContainer.php");
            }, 500);
        });

        var oldID = "";
        var checkUIDInterval = setInterval(checkUID, 1000);
        var updateUserInterval;

        function checkUID() {
            var uid = document.getElementById("getUID").innerHTML;
            if(uid !== "" && uid !== oldID) {
                oldID = uid;
                showUser(uid);
                clearInterval(checkUIDInterval);
                updateUserInterval = setInterval(updateUID, 500);
            }
        }

        function updateUID() {
            var uid = document.getElementById("getUID").innerHTML;
            if(uid !== oldID) {
                oldID = uid;
                showUser(uid);
            }
        }

        function showUser(uid) {
            if(uid === "") return;
            const xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if(this.readyState == 4 && this.status == 200) {
                    document.getElementById("user_data").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "read tag user data.php?id=" + uid, true);
            xmlhttp.send();
        }

        // Blinking text
        setInterval(function(){
            const blink = document.getElementById('blink');
            if(blink) blink.style.opacity = (blink.style.opacity == 0 ? 1 : 0);
        }, 750);
    </script>
</head>

<body>

    <h1>SBCA Student RFID System</h1>

    <ul class="topnav">
        <li><a href="home.php">Home</a></li>
        <li><a href="user_data.php">User Data</a></li>
        <li><a href="registration.php">Registration</a></li>
        <li><a class="active" href="read_tag.php">Read Tag</a></li>
    </ul>

    <div class="data-card">
        <h3 id="blink" class="blink">Please Tag to Display ID or User Data</h3>

        <p id="getUID"></p>

        <div id="user_data">
            <table>
                <tr><th colspan="2">User Data</th></tr>
                <tr><td>ID</td><td>--------</td></tr>
                <tr><td>Name</td><td>--------</td></tr>
                <tr><td>Gender</td><td>--------</td></tr>
                <tr><td>Email</td><td>--------</td></tr>
                <tr><td>Mobile Number</td><td>--------</td></tr>
            </table>
        </div>
    </div>

</body>
</html>
