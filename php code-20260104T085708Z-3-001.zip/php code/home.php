<?php
session_start();

// Prevent access if not logged in
if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit;
}
?>

<?php
    $Write="<?php $" . "UIDresult=''; " . "echo $" . "UIDresult;" . " ?>";
    file_put_contents('UIDContainer.php',$Write);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>

    <title>SBCA Student RFID Home</title>

    <style>
        /* Body background with logo */
        body {
            background: url('bernadettelogo.png') no-repeat left top;
            background-size: 400px;   /* adjust size */
            background-color: #fafafa;
        }

        h1 {
            font-family: "Engravers Old English", serif;
            margin-top: 40px;
            color: #b14134;
            text-align: center;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        }

        .topnav {
            list-style: none;
            margin: 30px auto 0;
            padding: 0;
            overflow: hidden;
            background: #b14134;
            width: 75%;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            text-align: center;
        }

        .topnav li { float: left; }
        .topnav li a {
            display: block;
            color: #fff;
            font-weight: 600;
            text-align: center;
            padding: 20px 26px;
            text-decoration: none;
            font-size: 18px;
            transition: 0.3s;
        }

        .topnav li a:hover:not(.active) { background: #d35b4d; }
        .active { background: #333; }

        @media (max-width: 768px) { .topnav li { float: none; } }

        h3 {
            margin-top: 35px;
            color: #444;
            font-weight: 700;
            text-align: center;
        }

        /* Card styling */
        .card-item {
            background: white;
            border-radius: 20px;
            box-shadow: 0 4px 18px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            overflow: hidden;
            transition: 0.3s;
        }

        .card-item:hover {
            transform: scale(1.02);
            box-shadow: 0 6px 22px rgba(0,0,0,0.15);
        }

        /* Photo fit inside card */
        .card-photo {
            width: 100%;
            height: 250px;
            object-fit: contain;
            background-color: #f0f0f0;
        }

        .card-body {
            padding: 20px;
        }

        .card-body h4 {
            color: #b14134;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .card-body p {
            font-size: 15px;
            color: #444;
            line-height: 1.5;
        }
    </style>
</head>

<body>
    <h1>SBCA Student RFID System</h1>

    <ul class="topnav">
        <li><a class="active" href="home.php">Home</a></li>
        <li><a href="user_data.php">User Data</a></li>
        <li><a href="registration.php">Registration</a></li>
        <li><a href="read_tag.php">Read Tag ID</a></li>
        <li style="float:right;"><a href="login.php">Login</a></li>
        <li style="float:right;"><a href="signup.php">Sign Up</a></li>
    </ul>

    <h3>Saint Bernadette College of Alabang RFID</h3>

    <div class="container mt-4">
        <div class="row">

            <!-- Card 1 -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card-item">
                    <img src="OIP.jpg" class="card-photo" alt="Photo 1">
                    <div class="card-body">
                        <h4>Welcome Box 1</h4>
                        <p>Welcome to the SBCA Student RFID System! Here you can manage student registrations, monitor attendance, and read RFID tags efficiently.</p>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card-item">
                    <img src="homepic1.jpg" class="card-photo" alt="Photo 2">
                    <div class="card-body">
                        <h4>Welcome Box 2</h4>
                        <p>This is a second info box. You can write additional instructions, announcements, or messages for students and staff.</p>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card-item">
                    <img src="OIP3.jpg" class="card-photo" alt="Photo 3">
                    <div class="card-body">
                        <h4>Welcome Box 3</h4>
                        <p>This third box can be used for news, updates, or other information relevant to the RFID system users.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</body>
</html>
