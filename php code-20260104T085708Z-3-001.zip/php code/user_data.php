<?php
    $Write="<?php $" . "UIDresult=''; " . "echo $" . "UIDresult;" . " ?>";
    file_put_contents('UIDContainer.php',$Write);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>

    <title>User Data : SBCA RFID System</title>

    <style>
        /* Body background with logo */
        body {
            background: url('bernadettelogo.png') no-repeat left top;
            background-size: 400px;   /* adjust size */
            background-color: #fafafa;
            text-align:center;
        }   

        h1 {
            font-family: "Engravers Old English", serif;
            margin-top: 35px;
            color: #b14134;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
        }

        /* Navigation Bar */
        .topnav {
            list-style: none;
            margin: 30px auto;
            padding: 0;
            overflow: hidden;
            background: #b14134;
            width: 75%;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .topnav li {
            float: left;
        }

        .topnav li a {
            display: block;
            color: #ffffff;
            font-weight: 600;
            text-align: center;
            padding: 18px 26px;
            text-decoration: none;
            font-size: 18px;
            transition: 0.3s;
        }

        .topnav li a:hover:not(.active) {
            background: #d35b4d;
        }

        .active {
            background: #333333;
        }

        @media (max-width: 600px) {
            .topnav li {
                float: none;
            }
        }

        /* Table Container */
        .container {
            margin-top: 40px;
            width: 85%;
            max-width: 1100px;
        }

        h3 {
            color: #444;
            font-weight: 700;
            margin-bottom: 25px;
        }

        /* Table Styling */
        table {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        thead {
            background: #10a0c5;
            color: white;
            font-size: 16px;
            text-transform: uppercase;
        }

        tbody tr:hover {
            background: #f1f9ff;
            transition: 0.2s;
        }

        td {
            vertical-align: middle;
            font-size: 15px;
        }

        /* Buttons */
        .btn-success {
            border-radius: 8px;
            padding: 6px 14px;
            font-weight: 600;
        }

        .btn-danger {
            border-radius: 8px;
            padding: 6px 14px;
            font-weight: 600;
        }

    </style>
</head>

<body>

    <h1>SBCA Student RFID System</h1>

    <ul class="topnav">
        <li><a href="home.php">Home</a></li>
        <li><a class="active" href="user_data.php">User Data</a></li>
        <li><a href="registration.php">Registration</a></li>
        <li><a href="read_tag.php">Read Tag ID</a></li>
    </ul>

    <div class="container">
        <h3>Student Data</h3>

        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>ID</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Mobile Number</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php
                   include 'database.php';
                   $pdo = Database::connect();
                   $sql = 'SELECT * FROM table_nodemcu_sbca_rfid__mysql ORDER BY name ASC';
                   foreach ($pdo->query($sql) as $row) {
                        echo '<tr>';
                        echo '<td>'. $row['name'] . '</td>';
                        echo '<td>'. $row['id'] . '</td>';
                        echo '<td>'. $row['gender'] . '</td>';
                        echo '<td>'. $row['email'] . '</td>';
                        echo '<td>'. $row['mobile'] . '</td>';
                        echo '<td>
                                <a class="btn btn-success" href="user data edit page.php?id='.$row['id'].'">Edit</a>
                                <a class="btn btn-danger" href="user data delete page.php?id='.$row['id'].'">Delete</a>
                              </td>';
                        echo '</tr>';
                   }
                   Database::disconnect();
                ?>
            </tbody>
        </table>
    </div>

</body>
</html>
