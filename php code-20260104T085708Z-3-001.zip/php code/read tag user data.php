<?php
session_start();  // Start session at the very beginning

require 'database.php';
require 'send_email.php'; // Keep this to include your email function

$id = null;
if (!empty($_GET['id'])) {
    $id = $_REQUEST['id'];
}

$pdo = Database::connect();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "SELECT * FROM table_nodemcu_sbca_rfid__mysql where id = ?";
$q = $pdo->prepare($sql);
$q->execute(array($id));
$data = $q->fetch(PDO::FETCH_ASSOC);
Database::disconnect();

$msg = null;
if (null == $data['name']) {
    $msg = "The ID of your Card / KeyChain is not registered !!!";
    $data['id'] = $id;
    $data['name'] = "--------";
    $data['gender'] = "--------";
    $data['email'] = "--------";
    $data['mobile'] = "--------";
} else {
    $msg = null;

    // Send email only if not sent before for this UID
    if ($data['email'] != "" && $data['email'] != "--------") {
        if (!isset($_SESSION['last_email_sent']) || $_SESSION['last_email_sent'] !== $id) {
            $_SESSION['last_email_sent'] = $id;

            $to = $data['email'];
            $subject = "RFID Attendance Notification";
            $message = "Hello " . $data['name'] . ",\n\nYou have just scanned your RFID tag.\n\nDate & Time: " . date("Y-m-d H:i:s") . "\n\nThank you.";

            // Call the sendEmail function from send_email.php
            sendEmail($to, $subject, $message);
        }
    }

    // -------------------------------
    // Record attendance in the database
    // -------------------------------
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO attendance (student_id, scan_time) VALUES (?, ?)";
    $q = $pdo->prepare($sql);
    $q->execute(array($data['id'], date("Y-m-d H:i:s")));
    Database::disconnect();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
    <style>
        td.lf {
            padding-left: 15px;
            padding-top: 12px;
            padding-bottom: 12px;
        }
    </style>
</head>

<body>
    <div>
        <form>
            <table width="452" border="1" bordercolor="#10a0c5" align="center" cellpadding="0" cellspacing="1" bgcolor="#000" style="padding: 2px">
                <tr>
                    <td height="40" align="center" bgcolor="#10a0c5"><font color="#FFFFFF"><b>User Data</b></font></td>
                </tr>
                <tr>
                    <td bgcolor="#f9f9f9">
                        <table width="452" border="1" align="center" cellpadding="5" cellspacing="1">
                            <tr>
                                <td width="113" align="left" class="lf">ID</td>
                                <td style="font-weight:bold">:</td>
                                <td align="left"><?php echo $data['id'];?></td>
                            </tr>
                            <tr bgcolor="#f2f2f2">
                                <td align="left" class="lf">Name</td>
                                <td style="font-weight:bold">:</td>
                                <td align="left"><?php echo $data['name'];?></td>
                            </tr>
                            <tr>
                                <td align="left" class="lf">Gender</td>
                                <td style="font-weight:bold">:</td>
                                <td align="left"><?php echo $data['gender'];?></td>
                            </tr>
                            <tr bgcolor="#f2f2f2">
                                <td align="left" class="lf">Email</td>
                                <td style="font-weight:bold">:</td>
                                <td align="left"><?php echo $data['email'];?></td>
                            </tr>
                            <tr>
                                <td align="left" class="lf">Mobile Number</td>
                                <td style="font-weight:bold">:</td>
                                <td align="left"><?php echo $data['mobile'];?></td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <p style="color:red;"><?php echo $msg;?></p>
</body>
</html>
