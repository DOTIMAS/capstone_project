<?php
// send_email.php
// This file sends an email to a given recipient

function sendEmail($to, $subject, $message) {
    $headers = "From: your-email@example.com\r\n"; // <-- Replace with your email
    $headers .= "Reply-To: your-email@example.com\r\n";
    $headers .= "Content-type: text/html\r\n";

    // Use PHP mail function
    if(mail($to, $subject, $message, $headers)) {
        return true; // email sent successfully
    } else {
        return false; // failed to send email
    }
}
?>
